abstract class Ticket {
  int codigo;
  String evento;
  double _valorBase;

  Ticket(this.codigo, this.evento, this._valorBase);

  double get valorBase => _valorBase;

  set valorBase(double valor) {
    if (valor <= 0) {
      throw Exception("Ingresso não pode ser gratuito");
    }
    _valorBase = valor;
  }

  void taxaConveniencia() {
    _valorBase *= 1.10;
  }

  Map<String, dynamic> toJson();
}
