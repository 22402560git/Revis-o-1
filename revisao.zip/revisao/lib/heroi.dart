import 'avatar.dart';

class Heroi extends Avatar {
  String armaFavorita;

  Heroi(String nome, String classe, int forca, this.armaFavorita)
      : super(nome, classe, forca);

  @override
  Map<String, dynamic> toJson() {
    return {
      'nome': nome,
      'classe': classe,
      'forca': forca,
      'armaFavorita': armaFavorita
    };
  }
}
