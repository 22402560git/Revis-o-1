abstract class Avatar {
  String nome;
  String classe;
  int _pontosForca;

  Avatar(this.nome, this.classe, this._pontosForca);

  int get forca => _pontosForca;

  set forca(int valor) {
    if (valor < 1 || valor > 20) {
      throw Exception("Atributo fora do limite permitido (1-20)");
    }
    _pontosForca = valor;
  }

  void aplicarFuria() {
    _pontosForca += 5;
  }

  Map<String, dynamic> toJson();
}
