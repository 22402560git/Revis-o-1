import 'ticket.dart';

class IngressoShow extends Ticket {
  String setor;

  IngressoShow(int codigo, String evento, double valor, this.setor)
      : super(codigo, evento, valor);

  @override
  Map<String, dynamic> toJson() {
    return {
      'codigo': codigo,
      'evento': evento,
      'valor': valorBase,
      'setor': setor
    };
  }
}
